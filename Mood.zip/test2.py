from flask import Flask
from textblob import TextBlob
import sys
import tweepy

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from flask import request, render_template
import re
import os
from config import Config
from flask import Flask, render_template, flash, request
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
import matplotlib
matplotlib.use('Agg')

def percentage(part,whole):
    return 100*float(part)/float(whole)
DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'

 
class ReusableForm(Form):
    name = TextField('Name:', validators=[validators.required()])
    name2=TextField('Name:',validators=[validators.required()])
    name3=TextField('Name',validators=[validators.required()])
    name4=TextField('Name',validators=[validators.required()])
    name5=TextField('Name',validators=[validators.required()])

@app.route("/", methods=['GET', 'POST'])

def hello():
    form = ReusableForm(request.form)
    print (form.errors)
    if request.method == 'POST':
        name=request.form['name']
        print (name)
        name2=request.form['name2']
        name3=request.form['name3']
        name4=request.form['name4']
        name5=request.form['name5']
        if form.validate():
        	x=[]
        	x.append(name)
        	x.append(name2)
        	x.append(name3)
        	x.append(name4)
        	x.append(name5)
        	pos=0
        	neg=0
        	neutral=0
        	polarity=0
        	for tweet in x:
        		analysis=TextBlob(tweet)
        		polarity+=analysis.sentiment.polarity
        		if(analysis.sentiment.polarity==0):
        			neutral+=1
        		elif(analysis.sentiment.polarity<0.00):
        			neg+=1
        		elif(analysis.sentiment.polarity>0.00):
        			pos+=1
        	figure = plt.figure()
        	pos=percentage(pos,5)
        	neg=percentage(neg,5)
        	neutral=percentage(neutral,5)
        	polarity=percentage(polarity,5)
        	pos = format(pos, '.2f')
        	neg = format(neg, '.2f')
        	neutral = format(neutral, '.2f')
        	if (polarity == 0):
        		flash('Neutral')
        	elif (polarity < 0.00):
        		flash('Negative')
        	elif (polarity > 0.00):
        		flash("Positive")
        	labels = ['Happy ['+str(pos)+'%]',
        	'Neutral ['+str(neutral)+'%]',
        	'Depressed ['+str(neg)+'%]']
        	sizes = [pos, neutral, neg]
        	colors = ['yellowgreen', 'gold', 'red']
        	patches, texts = plt.pie(sizes, colors = colors, startangle = 90)
        	plt.legend(patches, labels, loc = "best")
        	plt.title('How '+ 'you' + ' are feeling  '
        		+' by analyzing '
        		+' Test ')
        	plt.axis('equal')
        	plt.tight_layout()
        	(plt.show())
        	figure.savefig('sine_wave_plot2.svg')
        	l=[]
        	l.append(pos)
        	l.append(neg)
        	l.append(neutral)
        	width=1/1.5;
        	plt.bar(l, labels, width, color="blue")
        	plt.show()
        	plt.plot(l,labels)
        	plt.show()
        else:
        	flash('All the form fields are required. ')
    return render_template('mood-form.html', form=form)



app.run(port=7000)


