from flask import Flask
from textblob import TextBlob
import sys
import tweepy

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import io
import base64
from flask import request, render_template
import re
import os
from config import Config
from flask import Flask, render_template, flash, request
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
import matplotlib
matplotlib.use('Agg')

def percentage(part,whole):
    return 100*float(part)/float(whole)
consumerKey="3eZheUk2uQRxzR98yH5kd5YjO"
consumerSecret="CTit43dIlghmJ4NIQze0zm8Aoz3u1OIupjkL1xpTlsaqiUXC3V"
accessToken="1032533094413283329-MrHn5za1SMhN8g2gl6sbAOiy4samMw"
acessTokenSecret="fytkC1FNJ4Y0HnsqUYq3Sn7gLzcqlvZSnBaq4tFzlmO5K"
auth=tweepy.OAuthHandler(consumerKey,consumerSecret)
auth.set_access_token(accessToken,acessTokenSecret)
api = tweepy.API(auth)  
def get_tweets(str):
	tweets=api.user_timeline(screen_name=str,count=200)
	return tweets
# App config.
DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'

 
class ReusableForm(Form):
    name = TextField('Name:', validators=[validators.required()])
    
 
 
@app.route("/", methods=['GET', 'POST'])

def hello():
    form = ReusableForm(request.form)
 
    print (form.errors)
    if request.method == 'POST':
        name=request.form['name']
        print (name)
 
        if form.validate():
            # Save the comment here.
            flash('Hello ' + name)
            tweets=get_tweets(name)
            pos=0
            neg=0
            neutral=0
            polarity=0
            for tweet in tweets:
            	analysis=TextBlob(tweet.text)
            	polarity+=analysis.sentiment.polarity
            	if(analysis.sentiment.polarity==0):
            		neutral+=1
            	elif(analysis.sentiment.polarity<0.00):
            		neg+=1
            	elif(analysis.sentiment.polarity>0.00):
            		pos+=1
            figure = plt.figure()

            pos=percentage(pos,200)
            neg=percentage(neg,200)
            neutral=percentage(neutral,200)
            polarity=percentage(polarity,200)
            pos = format(pos, '.2f')
            neg = format(neg, '.2f')
            neutral = format(neutral, '.2f')
            if (polarity == 0):
            	flash('Neutral')
            elif (polarity < 0.00):
            	flash('Negative')
            elif (polarity > 0.00):
            	flash("Positive")
            labels = ['Happy ['+str(pos)+'%]',
            'Neutral ['+str(neutral)+'%]',
            'Depressed ['+str(neg)+'%]']
            sizes = [pos, neutral, neg]
            colors = ['yellowgreen', 'gold', 'red']
            patches, texts = plt.pie(sizes, colors = colors, startangle = 90)
            plt.legend(patches, labels, loc = "best")
            plt.title('How '+ name + ' is feeling  '
            	+' by analyzing '
            	+str(200)+' Tweets ')
            plt.axis('equal')
            plt.tight_layout()
                    
            (plt.show())
            plt.close()
            figure.savefig('sine_wave_plot.svg')
           
            l=[]
            l.append(pos)
            l.append(neg)
            l.append(neutral)
            width=1/1.5;
            plt.bar(l, labels, width, color="blue")
            plt.show()
            plt.close()
            plt.plot(l,labels)
            plt.show()
            plt.close()



        else:
            flash('All the form fields are required. ')
 
    return render_template('hello.html', form=form)

app.run()